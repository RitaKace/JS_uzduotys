// 1.1 uzduotis

cars.filter((car) => {
    return car.Miles_per_Gallon 
    });
 
 
 // 1.2 uzduotis
 
 cars.map((car)=>{
   return {
     Name: car.Name,
     Cylinders: car.Cylinders,
     Displacement: car.Displacement,
     Horsepower: car.Horsepower,
     Weight_in_lbs: car.Weight_in_lbs,
     Acceleration: car.Acceleration,
     Year: car.Year,
     Origin: car.Origin
   }
 });
 
 // 1.3 uzduotis
 
 
 cars.filter((car)=>{
   return (car.Cylinders == 8 && car.Miles_per_Gallon>=15)
 });
 
 // 1.4 uzduotis
 
 cars.forEach(car => {
   car.Kilowatts = ~~(car.Horsepower * 0.7457)
 });
 
 // 1.5 uzduotis
 
 cars.sort((a,b)=>a.Weight_in_lbs-b.Weight_in_lbs);
 
 
 // 1.6 uzduotis
 Object.values(cars).every(car => car.Origin === "USA");