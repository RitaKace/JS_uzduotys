var width = 20;
var height = 20;
function paspaude() {
  var box = document.createElement("div");
  box.setAttribute("class", "box");
  box.style.width = width+"px";
  box.style.height = height+"px";
  width = width + 20;
  height = height + 20;
  document.body.appendChild(box);
}

