setTimeout(changecolor, 3000);
function changecolor() {
  document.getElementById("changecolorElement").style.backgroundColor = "red"
}